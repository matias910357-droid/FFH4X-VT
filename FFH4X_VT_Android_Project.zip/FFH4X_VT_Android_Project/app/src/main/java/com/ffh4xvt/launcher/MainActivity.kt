package com.ffh4xvt.launcher

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Cyan = Color(0xFF37DCFF)
private val Background = Color(0xFF080D17)
private val Card = Color(0xFF14243A)

class MainActivity : ComponentActivity() {
    private var showPanel by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Background, surface = Card, primary = Cyan
            )) {
                LauncherScreen(
                    showPanel = showPanel,
                    onJoin = { launchFreeFire() },
                    onHide = { showPanel = false }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Al regresar de Free Fire, mostrar el panel independiente.
        if (hasLaunchedGame) {
            showPanel = true
            hasLaunchedGame = false
        }
    }

    private var hasLaunchedGame = false

    private fun launchFreeFire() {
        val packages = listOf("com.dts.freefireth", "com.dts.freefiremax")
        val launchIntent = packages.firstNotNullOfOrNull { packageName ->
            packageManager.getLaunchIntentForPackage(packageName)
        }
        if (launchIntent != null) {
            hasLaunchedGame = true
            showPanel = false
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
        } else {
            Toast.makeText(
                this,
                "No encontré Free Fire ni Free Fire MAX instalado.",
                Toast.LENGTH_LONG
            ).show()
            try {
                startActivity(Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=com.dts.freefireth")))
            } catch (_: ActivityNotFoundException) {
                startActivity(Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=com.dts.freefireth")))
            }
        }
    }
}

@Composable
private fun LauncherScreen(showPanel: Boolean, onJoin: () -> Unit, onHide: () -> Unit) {
    var selected by remember { mutableStateOf("PESCOÇO") }
    var fov by remember { mutableFloatStateOf(45f) }
    var precision by remember { mutableFloatStateOf(70f) }
    var distance by remember { mutableFloatStateOf(120f) }

    Column(
        modifier = Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF101D30), Background)))
            .verticalScroll(rememberScrollState())
            .padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("FFH4X VT", color = Cyan, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text("MOBILE CONTROL CENTER", color = Color.LightGray, fontSize = 10.sp)
        Spacer(Modifier.height(28.dp))

        if (!showPanel) {
            Text("Bienvenido", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Entrá al juego desde este lanzador.", color = Color.LightGray)
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = onJoin,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Cyan),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("UNIRSE A FREE FIRE", color = Background, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(14.dp))
            Text("Al volver a esta aplicación se mostrará el panel.", color = Color.Gray, fontSize = 12.sp)
        } else {
            Text("Panel de control", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(18.dp))
            PanelCard {
                Text("SELECCIÓN DE OBJETIVO", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("PESCOÇO", "PEITO", "CABEÇA").forEach { item ->
                        FilterChip(
                            selected = selected == item,
                            onClick = { selected = item },
                            label = { Text(item, fontSize = 10.sp) }
                        )
                    }
                }
                SliderSetting("FOV (visual)", fov, { fov = it }, "45")
                SliderSetting("Precisión (visual)", precision, { precision = it }, "70%")
                SliderSetting("Distancia (visual)", distance, { distance = it }, "120 m")
            }
            PanelCard {
                Text("SEGURIDAD", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Text("Anti-ban y Anti-blacklist no están disponibles: ninguna opción puede garantizar evitar sanciones o bloqueos.", color = Color(0xFFFFD49C), fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text("Este panel es independiente. No modifica Free Fire, no inyecta código ni altera partidas.", color = Color.LightGray, fontSize = 11.sp)
            }
            OutlinedButton(onClick = onHide, modifier = Modifier.fillMaxWidth()) {
                Text("VOLVER AL INICIO")
            }
        }
    }
}

@Composable
private fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp),
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = Card)
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
private fun SliderSetting(label: String, value: Float, onValue: (Float) -> Unit, suffix: String) {
    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color.White, fontSize = 13.sp)
        Text("${value.toInt()}${if (suffix == "45") "" else if (suffix == "70%") "%" else " m"}", color = Cyan)
    }
    Slider(value = value, onValueChange = onValue, valueRange = 0f..100f)
}
