FFH4X VT - Proyecto Android

Este es el código fuente de una app lanzadora independiente.
- Muestra un botón para abrir Free Fire o Free Fire MAX si está instalado.
- Al volver a la app, muestra un panel visual independiente.
- Los controles son demostrativos y no afectan al juego.
- No incluye funciones de inyección, trampas, evasión de detección ni anti-ban.

Para generar un APK:
1. Abrí la carpeta del proyecto con Android Studio.
2. Esperá a que termine la sincronización de Gradle.
3. Elegí Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio generará el APK en app/build/outputs/apk/debug/.

Requiere Android Studio y conexión a internet para descargar las dependencias.
